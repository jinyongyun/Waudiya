//
//  Cell.swift
//  waudiya
//
//  Created by mac on 2022/08/09.
//

import UIKit

class Cell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var subtitleLabel: UILabel!
    
}
